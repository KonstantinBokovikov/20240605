#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <mpi.h>

using namespace std;

int main(int* argc, char** argv)
{
	setlocale(LC_ALL, "Russian");
	MPI_Init(argc, &argv);
	int size, rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0) 
    {   
        string alphabet = "abcdefghijklmnopqrstuvwxyz";
        char symbol;
        int in_str1 = 1, in_str2 = 1, k = 0;
        srand(time(0));
        MPI_Status status;
        while (in_str1 != 0 and in_str2 != 0)
        {
            k++;
            symbol = alphabet[rand() % 26];
            cout << "Number of iteration: " << k << endl;
            cout << "Symbol - " << symbol << endl;
            MPI_Send(&symbol, 1, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
            MPI_Send(&symbol, 1, MPI_CHAR, 2, 1, MPI_COMM_WORLD);
            MPI_Recv(&in_str1, 1, MPI_INT, 1, 2, MPI_COMM_WORLD, &status);
            MPI_Recv(&in_str2, 1, MPI_INT, 2, 5, MPI_COMM_WORLD, &status);
        }
            
    }
    if (rank == 1)
    {
        char symbol;
        int in_str1 = 1, in_str2 = 1;
        MPI_Status status;
        srand(time(0));
        string alphabet1 = "abcdefghijklmnopqrstuvwxyz";
        while (in_str1 != 0 and in_str2 != 0)
        {
            int length = rand() % 100;
            string str1;
            str1.resize(length);
            MPI_Recv(&symbol, 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &status);
            for (int i = 0; i < length; i++)
            {
                str1[i] = alphabet1[rand() % 26];
            }
            cout << "Line 1 - " << str1 << endl;
            in_str1 = 0;
            for (int i = 0; i < length; i++)
                if (str1[i] == symbol)
                    in_str1++;
            cout << "Number of occurrences in a string 1 - " << in_str1 << endl;
            MPI_Send(&in_str1, 1, MPI_INT, 2, 3, MPI_COMM_WORLD);
            MPI_Send(&in_str1, 1, MPI_INT, 0, 2, MPI_COMM_WORLD);
            MPI_Recv(&in_str2, 1, MPI_INT, 2, 4, MPI_COMM_WORLD, &status);
        }
    }
    if (rank == 2)
    {
        char symbol;
        int in_str1 = 1, in_str2 = 1;
        MPI_Status status;
        srand(time(0));
        string alphabet2 = "zyxwvutsrqponmlkjihgfedcba";
        while (in_str1 != 0 and in_str2 != 0)
        {
            int length = rand() % 100;
            string str2;
            str2.resize(length);
            MPI_Recv(&symbol, 1, MPI_CHAR, 0, 1, MPI_COMM_WORLD, &status);
            for (int i = 0; i < length; i++)
            {
                str2[i] = alphabet2[rand() % 26];
            }
            MPI_Recv(&in_str1, 1, MPI_INT, 1, 3, MPI_COMM_WORLD, &status);
            cout << "Line 2 - " << str2 << endl;
            in_str2 = 0;
            for (int i = 0; i < length; i++)
                if (str2[i] == symbol)
                    in_str2++;
            cout << "Number of occurrences in a string 2 - " << in_str2 << endl << endl;
            MPI_Send(&in_str2, 1, MPI_INT, 1, 4, MPI_COMM_WORLD);
            MPI_Send(&in_str2, 1, MPI_INT, 0, 5, MPI_COMM_WORLD);
        }
    }
    MPI_Finalize();
    return 0;
}