#define HAVE_STRUCT_TIMESPEC
#include <pthread.h>
#include <iostream>
#include <string>
#include <cmath>
#include <fstream>

using namespace std;

int l;
int N;
int* A;
pthread_mutex_t mutex;
ofstream out;

void* func(void* arg)
{
	int nomer = *(int*)arg;
	int begin = (l / 3) * (nomer - 1);
	int end = (l / 3) * (nomer);
	if (nomer == 3) {
		end = l - 1;
	}
	bool f=true;

	for (int i = begin; i <= end; i++)
	{
		string s = to_string(A[i]);
		for (int j = 0; j < s.length()/2; j++)
		{
			if (s[j] == s[s.length() - 1 - j])
				f = true;
			else
			{
				f = false;
				break;
			}
		}
		if (f == true)
		{
			pthread_mutex_lock(&mutex);
			out << A[i] << endl;
			pthread_mutex_unlock(&mutex);
		}
			
	}
	return NULL;
}

int main()
{
	pthread_mutexattr_t mattr;
	pthread_mutexattr_init(&mattr);
	pthread_mutexattr_settype(&mattr, PTHREAD_MUTEX_NORMAL);
	pthread_mutex_init(&mutex, &mattr);

	setlocale(LC_ALL, "Russian");
	cout << "������� ����������� �����: ";
	cin >> N;
	int p_number[] = { 1, 2, 3 };
	l = pow(10, N) - pow(10, N - 1);
	A = new int[pow(10,N)-pow(10,N-1)];
	for (int i = 0; i < pow(10, N) - pow(10, N - 1); i++)
	{
		A[i] = pow(10, N - 1) + i;
	}

	pthread_t* p;
	p = new pthread_t[3];

	out.open("Res.txt");

	for (int i=0;i<3;i++)
		pthread_create(&p[i], NULL, func, (void*)&p_number[i]);
	for (int i=0;i<3;i++)
		pthread_join(p[i], NULL);
	
	out.close();

	cout << "�������, ��������� ��������� ���� ������. ���������� � ������ Res.txt :)" << endl;

	delete[] A;
	delete[] p;


	return 0;
}