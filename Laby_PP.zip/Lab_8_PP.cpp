#define HAVE_STRUCT_TIMESPEC
#include <pthread.h>
#include <iostream>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

pthread_barrier_t barr;
string alphabet = "abcdefghijklmnopqrstuvwxyz";
char symbol;
int in_str1 = 1, in_str2 = 1, k = 0;

void* generate(void* arg)
{
	srand(time(0));
	while (in_str1 != 0 and in_str2 != 0)
	{
		k++;
		symbol = alphabet[rand()%26];
		cout << "����� ��������: " << k << endl;
		cout << "������ - " << symbol << endl;
		pthread_barrier_wait(&barr);
		pthread_barrier_wait(&barr);
		pthread_barrier_wait(&barr);
	}
	return 0;
}

void* f_1(void* arg)
{
	srand(time(0));
	string alphabet1 = "abcdefghijklmnopqrstuvwxyz";
	while (in_str1 != 0 and in_str2 != 0)
	{
		int length = rand()%100;
		string str1;
		str1.resize(length);
		pthread_barrier_wait(&barr);
		for (int i = 0; i < length; i++)
		{
			str1[i] = alphabet1[rand()%26];
		}
		cout << "������ 1 - " << str1 << endl;
		in_str1 = 0;
		for (int i = 0; i < length; i++)
			if (str1[i] == symbol)
				in_str1++;
		cout << "����� ��������� � ������ 1 - " << in_str1 << endl;
		pthread_barrier_wait(&barr);
		pthread_barrier_wait(&barr);
	}
	return 0;
}

void* f_2(void* arg)
{
	srand(time(0));
	string alphabet2 = "zyxwvutsrqponmlkjihgfedcba";
	while (in_str1 != 0 and in_str2 !=0)
	{
		int length = rand() % 110;
		string str2;
		str2.resize(length);
		pthread_barrier_wait(&barr);
		for (int i = 0; i < length; i++)
		{
			str2[i] = alphabet2[rand() % 26];
		}
		pthread_barrier_wait(&barr);
		cout << "������ 2 - " << str2 << endl;
		in_str2 = 0;
		for (int i = 0; i < length; i++)
			if (str2[i] == symbol)
				in_str2++;
		cout << "����� ��������� � ������ 2 - " << in_str2 << endl << endl;
		pthread_barrier_wait(&barr);
	}
	return 0;
}

int main()
{
	setlocale(LC_ALL, "Russian");

	pthread_barrier_init(&barr, NULL, 3);
	pthread_t p1, p2, p3;

	pthread_create(&p1, NULL, generate, NULL);
	pthread_create(&p2, NULL, f_1, NULL);
	pthread_create(&p3, NULL, f_2, NULL);
	pthread_join(p1, NULL);
	return 0;
}