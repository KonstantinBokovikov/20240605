#define HAVE_STRUCT_TIMESPEC
#include <pthread.h>
#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int l;
int N;
int* A;
int *B;

void* func(void* arg)
{
	int nomer = *(int*)arg;
	int begin = (l / 3) * (nomer - 1);
	int end = (l / 3) * (nomer);
	if (nomer == 3) {
		end = l - 1;
	}
	bool f=true;

	for (int i = begin; i <= end; i++)
	{
		string s = to_string(A[i]);
		for (int j = 0; j < s.length()/2; j++)
		{
			if (s[j] == s[s.length() - 1 - j])
				f = true;
			else
			{
				f = false;
				break;
			}
		}
		if (f == true)
		{
			B[i] = A[i];
		}
			
	}
	return NULL;
}

int main()
{
	setlocale(LC_ALL, "Russian");
	cout << "������� ����������� �����: ";
	cin >> N;
	int p_number[] = { 1, 2, 3 };
	l = pow(10, N) - pow(10, N - 1);
	A = new int[pow(10,N)-pow(10,N-1)];
	B = new int[pow(10, N) - pow(10, N - 1)];
	for (int i = 0; i < pow(10, N) - pow(10, N - 1); i++)
	{
		A[i] = pow(10, N - 1) + i;
		B[i] = -1;
	}

	pthread_t* p;
	p = new pthread_t[3];

	for (int i=0;i<3;i++)
		pthread_create(&p[i], NULL, func, (void*)&p_number[i]);
	for (int i=0;i<3;i++)
		pthread_join(p[i], NULL);

	for (int i = 0; i < pow(10, N) - pow(10, N - 1); i++)
	{
		if (B[i] == -1) {
			continue;
		}
		cout << B[i] << endl;
	}

	delete[] A;
	delete[]B;
	delete[] p;

	return 0;
}