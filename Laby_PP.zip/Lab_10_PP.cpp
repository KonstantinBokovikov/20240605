﻿#include "cuda_runtime.h"
#include "device_launch_parameters.h"
#include <stdio.h>
#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <cuda.h>
#include <cmath>


using namespace std;

__global__ void StartThreads(float* matr) { //Заполнение матрицы псевдослучаными числами
    int threadId = threadIdx.x;
    unsigned int m_w = threadId;
    unsigned int m_z = 45;

    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    matr[threadId] = ((m_z << 16) + m_w) % 100;
       
}

int main()
{
    float** a;
    float** b;
    float** c;
    long long det = 1;
    int n = 16, k;
    float* matr;
    matr = new float[n * n];

    float* for_gpu; //Работа с видеокартой
    cudaMalloc((void**)&for_gpu, n * n * sizeof(float));
    //cudaMemcpy(for_gpu, matr, sizeof(int) * n * n, cudaMemcpyHostToDevice);
    StartThreads << < dim3(1), dim3(n*n) >> > (for_gpu);
    cudaMemcpy(matr, for_gpu, n * n * sizeof(float), cudaMemcpyDeviceToHost);
    cudaDeviceSynchronize();
    cudaFree(for_gpu);

    a = new float* [n]; //Матрица для работы
     for (int i = 0; i < n; i++)
         a[i] = new float[n];

    c = new float* [n]; //Матрица для работы
    for (int i = 0; i < n; i++)
        c[i] = new float[n];

    b = new float* [n - 1]; //Матрица для миноров
    for (int i = 0; i < n - 1; i++)
        b[i] = new float[n - 1];

    for (int i = 0; i < n; i++) //Копируем из одномерного заполненного GPU массива в двумерные
        for (int j = 0; j < n; j++) 
        {
            c[i][j] = matr[n * i + j];
            a[i][j] = matr[n * i + j];
        }
    
    for (int i = 0; i < n; i++) //Вывод на экран входной матрицы
    {
        for (int j = 0; j < n; j++)
            cout << c[i][j] << '\t';
        cout << endl;
    }

    for (int i = 1; i < n; ++i) //Приведение входной матрицы к треугольному виду
        for (k = i; k < n; ++k)
            for (int j = n - 1; j >= 0; --j)
                if (c[k][i - 1] != 0 && c[i - 1][i - 1] != 0 && c[i - 1][j] != 0)
                    c[k][j] -= (c[k][i - 1] / c[i - 1][i - 1] * c[i - 1][j]);


    for (int i = 0; i < n; i++) { //Считаем детерминант, если он равен 0, то выходим из программы
        det *= c[i][i];
    }
    cout << "Determenant " << det << endl;
    if (det == 0)
    {
        cout << "Error!";
        exit(0);
    }

    for (int col = 0; col < n; col++) //Начинаем поиск матрицы дополнений, считая миноры
    {
        for (int row = 0; row < n; row++)
        {
            int x = 0, y = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i != col && j != row)
                    {
                        b[x][y] = a[i][j];
                        if (y + 1 == n - 1)
                        {
                            x++;
                            y = 0;
                        }
                        else y++;
                    }
                }

            }
            for (int l = 1; l < n - 1; ++l)
                for (k = l; k < n - 1; ++k)
                    for (int m = n - 1; m >= 0; --m)
                        if (b[k][l - 1] != 0 && b[l - 1][l - 1] != 0 && b[l - 1][m] != 0)
                            b[k][m] -= (b[k][l - 1] / b[l - 1][l - 1] * b[l - 1][m]);
            long long det = 1;
            for (int z = 0; z < n-1; z++)
                det *= b[z][z];
            c[col][row] = det * pow(-1, col + 1 + row + 1);
        }
    }

    float temp; //Транспонируем матрицу дополнений
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
        {
            temp = c[i][j];
            c[i][j] = a[j][i];
            c[j][i] = temp;
        }

    for (int i = 0; i < n; i++) //Находим обратную матрицу
        for (int j = 0; j < n; j++)
            c[i][j] = c[i][j] / det;

    for (int i = 0; i < n; i++) //Вывод результата на экран
    {
        for (int j = 0; j < n; j++)
            cout << с[i][j] << '\t';
        cout << endl;
    }

    return 0;
}
