#define HAVE_STRUCT_TIMESPEC
#include <pthread.h>
#include <iostream>
#include <cmath>

using namespace std;

int N;
double* A;
double* S;
double* C;

void* sinus(void* arg)
{
	for (int i = 1; i <= N; i++)
		S[i] = sin(i);
	return NULL;
}

void* cosinus(void* arg)
{
	for (int i = 1; i <= N; i++)
		C[i] = cos(i);
	return NULL;
}

int main()
{
	setlocale(LC_ALL, "Russian");
	cout << "������� ����� ���������: ";
	cin >> N;
	A = new double[N];
	S = new double[N];
	C = new double[N];

	pthread_t p_sin;
	pthread_t p_cos;

	pthread_create(&p_sin, NULL, sinus, NULL);
	pthread_create(&p_cos, NULL, cosinus, NULL);

	pthread_join(p_sin, NULL);
	pthread_join(p_cos, NULL);

	for (int i = 1; i <= N; i++)
	{
		A[i] = pow(-1, i + 1) * i * (S[i] + C[i]);
		cout << A[i] << endl;
	}
	return 0;
}