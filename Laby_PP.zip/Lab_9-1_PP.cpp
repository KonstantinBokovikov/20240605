#include <iostream>
#include <cmath>
#include <mpi.h>

using namespace std;

int N;
double* A;
double* S;
double* C;
double* buf;
double* buf2;



int main(int* argc, char** argv)
{
	setlocale(LC_ALL, "Russian");
	MPI_Init(argc, &argv);
	int size, rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 1) 
    {   
        int N;
        MPI_Status status;
        MPI_Recv(&N, 1, MPI_INT, 0, 2, MPI_COMM_WORLD, &status);
        S = new double[N];
        for (int i = 1; i <= N; i++)
            S[i-1] = sin(i);
        MPI_Send(S, N, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
            
    }
    if (rank == 2)
    {
        int N;
        MPI_Status status;
        MPI_Recv(&N, 1, MPI_INT, 0, 3, MPI_COMM_WORLD, &status);
        C = new double[N];
        for (int i = 1; i <= N; i++)
            C[i-1] = cos(i);
        MPI_Send(C, N, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);
    }
    if (rank == 0)
    {
        cout << "Enter number of elements: ";
        cin >> N;
        MPI_Send(&N, 1, MPI_INT, 1, 2, MPI_COMM_WORLD);
        MPI_Send(&N, 1, MPI_INT, 2, 3, MPI_COMM_WORLD);
        buf = new double[N];
        buf2 = new double[N];
        MPI_Status status;
        MPI_Recv(buf, N, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD, &status);
        cout << endl;
        MPI_Recv(buf2, N, MPI_DOUBLE, 2, 1, MPI_COMM_WORLD, &status);
        for (int i = 1; i <= N; i++)
            cout << pow(-1, i + 1) * i * (buf[i-1] + buf2[i-1]) << endl;
    }
    MPI_Finalize();
    return 0;
}